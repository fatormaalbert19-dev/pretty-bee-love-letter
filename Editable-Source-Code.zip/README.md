# The cars are finally flying

A rose-red, blush-pink, and gold digital love letter from Berto to Bee. Editorial typography, arch-framed real portraits, quiet motion, and their flying-car joke connect eight chapters: introduction, actual messages, portrait gallery, little things, video, flying-car callback, letter, and the question.

## Run

Use Node 20 or newer. Run `npm ci`, then `npm run dev`. Run `npm run build` for TypeScript validation and the production build. `npm run preview` previews the build.

## Source and copy

`src/main.tsx` contains every line of site copy, media placements, interaction logic, and the eight narrative sections. `src/style.css` contains the responsive rose/pink/gold design. The application uses React, TypeScript, Vite, Tailwind CSS, and Framer Motion. Reduced-motion preferences are respected.

## Real media

All supplied photos, four screenshots, and the video are integrated already. `ASSETS.json` maps the original uploads to the descriptive filenames in `public/media`. Images were compressed to WebP without modifying faces. Replace a file with another using the same name, or update references in `src/main.tsx`. For different image dimensions, review object positioning in the CSS.

- black.webp: opening portrait and gallery
- blue.webp: gallery and final question
- green.webp, pink.webp, monochrome.webp: gallery
- chat-1.webp through chat-4.webp: expandable original messages
- bee.mp4: featured video

## Music

The supplied “Can you be mine .wav” is included as an optimized 192 kbps MP3 in `public/media/our-song.mp3`. It starts at 55% volume after the visitor taps “Okay, hear me out.” Browser playback requires that initial tap. The soundtrack panel also provides Play/Pause and Mute/Unmute. The song loops. Playing the featured video pauses the song. Replace our-song.mp3 to update the soundtrack.

## Answers

Both buttons open respectful response dialogs. Yes triggers gold/rose confetti and displays a WhatsApp button addressed to +16144969387. The prewritten message is: “Yes, Berto, I want to be your girlfriend, and I’d be honored to be with you. ❤️” The visitor must press Send inside WhatsApp. No message is sent automatically. The other response retains a gentle sharing option.

## Deploy to Vercel

1. Put this source in a GitHub, GitLab, or Bitbucket repository, keeping node_modules and dist excluded.
2. Import that repository as a new Vercel project.
3. Select the Vite preset, use `npm run build`, and set output directory to `dist`.
4. Deploy. No environment variables are required.
5. Open the resulting URL on a phone and check the gallery, video, music, and both answer buttons before sending it.

The generated `.openai/hosting.json` is for ChatGPT Sites and is not required by Vercel. This project has no client-side routes requiring rewrites. Treat the photos and chats as personal media when choosing hosting access. The ChatGPT Sites version starts owner-private.

## Validation

Production build and TypeScript checks pass. Browser checks confirmed the supplied song loads and plays after the entry tap, and the Yes dialog exposes the correct WhatsApp destination and encoded message. No automatic message is sent by this app.
